#ifndef _ASM_H
#define _ASM_H

#include <system.h>
#include <core/tables.h>

#endif
