#ifndef dispatcher_h
#define dispatcher_h

#include <modules/pcb.h>

PCB *loader(char* name, void (*func)(void));

void yield();

void insertIdle();

#endif
