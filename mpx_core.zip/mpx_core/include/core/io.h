#ifndef _IO_H
#define _IO_H

/*
  Procedure..: outb
  Description..: Write a byte of data to a port.
*/
#define outb(port, data)					\
  asm volatile ("outb %%al,%%dx" : : "a" (data), "d" (port))

/*
  Procedure..: inb
  Description..: Read a byte of data from a port.
*/
#define inb(port) ({						\
      unsigned char r;						\
      asm volatile ("inb %%dx,%%al": "=a" (r): "d" (port));	\
      r;							\
    })

#define RESET 0
#define SET 1

/*
 I/O Device
 */
typedef struct IOD {
    char *name;
    PCB *process;
    int opCode;
    char *buffer;
    int *count;
    struct IOD *next;
} IOD;

/*
 I/O Control Block
 */
typedef struct IOCB {
    int count;
    int *eventFlag;
    IOD *head;
    IOD *tail;
} IOCB;

/*
 Insert IOD into IOCB queue
 */
int enqueue(IOD *iod, IOCB *queue);

/*
 Remove IOD from IOCB queue
 */
IOD *dequeue(IOCB *queue);

/*
 Initialize IOD
 */
IOD *setupIOD();

/*
 Initialize IOCB
 */
IOCB *setupIOCB();

#endif
