#ifndef scheduler_h
#define scheduler_h

#include <system.h>
#include <core/io.h>

/*
 I/O Scheduler
 */
void scheduler();

/*
 Return IOCB Queue
 */
IOCB *getIOCB();

#endif
