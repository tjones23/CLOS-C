#ifndef _SERIAL_H
#define _SERIAL_H

#define COM1 0x3f8
#define COM2 0x2f8
#define COM3 0x3e8
#define COM4 0x2e8

#define PIC_CMD 0x20
#define PIC_MASK 0x21
#define INT_ENABLE COM1+1
#define INT_DISABLE COM1+4
#define LSB COM1
#define MSB COM1+1
#define INT_ID_REG COM1+2
#define LC_REG COM1+3
#define MC_REG COM1+4
#define LS_REG COM1+5
#define MS_REG COM1+6
#define EOI 0x20


#define NO_ERROR 0
#define INV_EFLAG (-101)
#define INV_BRD (-102)
#define PORT_OPEN (-103)
#define PORT_CLOSED (-201)

#define VEC_ADDR (0x60L*4)


/*
 Device Control Block
 */
#define OPENED -9999
#define CLOSED -9998

typedef struct DCB {
    int flag;
    int *eventFlag;
    int status;
    
    char *inBuffer;
    int *inCount;
    int inSize;
    
    char *outBuffer;
    int *outCount;
    int outSize;
    
    char ringBuffer[96];
    int ringBufferIn;//index to write next character
    int ringBufferOut;//index where the next character will be removed
    int ringBufferCount; //count of # characters stored but not read from buffer
} DCB;

/*
 Initalizes the DCB
 */
DCB *setupDCB();

/*
  Procedure..: init_serial
  Description..: Initializes devices for user interaction, logging, ...
*/
int init_serial(int device);

/*
  Procedure..: serial_println
  Description..: Writes a message to the active serial output device.
    Appends a newline character.
*/
int serial_println(const char *msg);

/*
  Procedure..: serial_print
  Description..: Writes a message to the active serial output device.
*/
int serial_print(const char *msg);

/*
  Procedure..: set_serial_out
  Description..: Sets serial_port_out to the given device address.
    All serial output, such as that from serial_println, will be
    directed to this device.
*/
int set_serial_out(int device);

/*
  Procedure..: set_serial_in
  Description..: Sets serial_port_in to the given device address.
    All serial input, such as console input via a virtual machine,
    QEMU/Bochs/etc, will be directed to this device.
*/
int set_serial_in(int device);

/*
 I/O Module Read Function w/ Helper
 */
void readComm();

int commRead(char *buffer, int *count);

/*
 I/O Module Write Function w/ Helper
 */
void writeComm();

int commWrite(char *buffer, int *count);

/*
 
 */
int comOpen(int *eflap_p, int baud_rate);

/*
 
 */
int comClose();

DCB *getDCB();

#endif
