#ifndef _COMMHAND_H
#define _COMMHAND_H

#define COMM_COUNT 31
#define VERSION 0
#define HELP 1
#define SHUTDOWN 2
#define GET_DATE 3
#define SET_DATE 4
#define GET_TIME 5
#define SET_TIME 6
#define SUSPEND 7
#define RESUME 8
#define SET_PRIORITY 9
#define SHOW_PCB 10
#define SHOW_ALL 11
#define SHOW_READY 12
#define SHOW_BLOCKED 13
#define CREATE_PCB 14
#define DELETE_PCB 15
#define BLOCK 16
#define UNBLOCK 17
#define CLEARQUEUES 18
#define CLEAR 19
#define YIELD 20
#define LOADR3 21
#define RESUME_ALL 22
#define SET_ALARM 23
#define SHOW_ALLOCATED 24
#define SHOW_FREE 25
#define IS_EMPTY 26
#define SHOW_HEAP 27
#define INIT_HEAP 28
#define FREE_MCB 29
#define ALLOCATE_MCB 30

#define BREAK 0
#define CONTINUE 1
#define KILL 2
#define ERROR 3

#include <core/dispatcher.h>

typedef struct COMMAND {
  char* info;
  char* help;
  int (*func)(void);
} COMMAND;

COMMAND COMM_LIST[COMM_COUNT];

int commYield(void);

int commLoadr3(void);

/**
   Starts kmain loop- prompts user input
*/
void init_commhandler(void);

#endif
