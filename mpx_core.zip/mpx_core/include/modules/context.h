#ifndef context_h
#define context_h

#include <system.h>

typedef unsigned long  u32int;

typedef struct Context {
    u32int gs, fs, es, ds;
    u32int edi, esi, ebp, esp, ebx, edx, ecx, eax;
    u32int eip, cs, eflags;
} context;

#endif
