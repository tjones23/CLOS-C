#ifndef date_h
#define date_h

/**********************************************************
 *   This function is used to get the current time from the RTC register
 *   Paramaters: int hours, int minutes, int seconds
 *
 *   Author: Corrie Shaffer
 ***********************************************************/
int getTime();

/*
 Command Handler Get Time
 */
int commGetTime();

/**********************************************************
 *   This function is used to set the time to the RTC register
 *   Paramaters: int hours, int mins, int secs
 *
 *   Author: Corrie Shaffer
 ***********************************************************/
int setTime(int hours, int minutes, int seconds);

/*
 Command Handler Set Time
 */
int commSetTime();


/**********************************************************
 *   This function is used to get the current date from the RTC register
 *   Paramaters: int day, int month, int year
 *
 *   Author: Corrie Shaffer
 ***********************************************************/
int getDate();

/*
 Command Handler Get Date
 */
int commGetDate();


/**********************************************************
 *   This function is used to set the date to the RTC register
 *   Paramaters: int day, int month, int year
 *
 *   Author: Corrie Shaffer
 ***********************************************************/

int setDate(int d, int m, int y);

/*
 Command Handler Set Date
 */
int commSetDate();


/**********************************************************
 *   This function is used to conver BCD to decimal
 *   Paramaters: int BCD
 *
 *   Author: Corrie Shaffer
 ***********************************************************/

int BCDToDecimal(int BCD);


/**********************************************************
 *   This function is used to get the current time from the RTC register
 *   Paramaters: int decimal
 *
 *   Author: Corrie Shaffer
 ***********************************************************/

int DecToBCD(int dec);

/**
 Alarm function
 */
int commSetAlarm();

#endif
