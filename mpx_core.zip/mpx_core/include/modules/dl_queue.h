#ifndef dl_queue_h
#define dl_queue_h

#include "pcb.h"

// Queue
/* typedef struct QUEUE {
    int count;
    PCB *head;
    PCB *tail;
} QUEUE; */

/**
 Insert PCB in queue in proper order
 */
// void insertPCB(PCB* pcb);

/**
 Search both queues for PCB
 */
// PCB* findPCB(char* pcbName);

/**
 Remove PCB
 */
// int removePCB(PCB* pcb);

/**
 Print PCBs in both queues
 */
// void printQueues();

#endif
