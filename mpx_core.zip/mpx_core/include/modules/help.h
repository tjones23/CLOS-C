#ifndef _HELP_H
#define _HELP_H

/**
   Function for help command
   @return int - loop signal
*/

int  helpComm(void);

#endif
