#ifndef mem_manager_h
#define mem_manager_h

#include <system.h>
#include <string.h>
#include <core/serial.h>
#include <mem/heap.h>

#define ALLOCATED 0
#define FREE 1
#define CONTINUE 1
#define ERROR_REQUEST_TOO_SMALL -10
#define ERROR_SPACE_UNAVAILABLE -20

typedef unsigned long u32int;

/*
 Memory Control Block
 */
typedef struct MCB {
    int type;
    int size;
    u32int addr;
    char *name;
    struct MCB *next;
    struct MCB *prev;
} MCB;

typedef struct List {
    MCB *head;
} List;

void printBlock(MCB *curr);
int isEmpty();
int compareMCB(MCB *m1, MCB *m2);
u32int shiftMCB(u32int ptr, int shift);
u32int getUsableAddress(MCB *mcb);
u32int relativeAddress(u32int mcb);

MCB *heapPrevFree(MCB *mcb);
MCB *heapPrevAllocated(MCB *mcb);
MCB *heapPrevMCB(MCB *mcb);
MCB *heapNextFree(MCB *mcb);
MCB *heapNextAllocated(MCB *mcb);
MCB *heapNextMCB(MCB *mcb);

void fillMCB(MCB *mcb, int type, int size, u32int addr, char *name, MCB *next, MCB *prev);
MCB *findMCB(u32int addr);
MCB *findParent(u32int p);
void insertFreeMCB(MCB *mcb);
void insertAllocatedMCB(MCB *mcb);
void insertMCB(MCB *mcb);
void removeFreeMCB(MCB *mcb);
void removeAllocatedMCB(MCB *mcb);
void removeMCB(MCB *mcb);

int initHeap(int size);
u32int myAlloc(u32int size);
int myFree(void *p);

int commFreeMCB();
int commInitHeap();
int commAllocateMCB();
int commPrintAllocated();
int commPrintFree();
int commPrintIsEmpty();
int commPrintHeap();

int main();

#endif
