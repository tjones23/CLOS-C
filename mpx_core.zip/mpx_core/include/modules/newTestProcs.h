#ifndef newTestProcs_h
#define newTestProcs_h

void COMWRITE();

void COMREAD();

void IOCOM25();

void IOCOM();

#endif
