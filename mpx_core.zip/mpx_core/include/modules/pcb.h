#ifndef _PCB_H
#define _PCB_H

#define READY 1
#define RUNNING 2
#define BLOCKED 3
#define SUSPENDED 4
#define NOT_SUSPENDED 5

/**
 Process Control Block
 */
typedef struct PCB {
    char pcbName [20];
    int pcbClass;
    int priority;
    int state;
    int rrb;
    unsigned char stackBase [1024];
    unsigned char *stackTop;
    struct PCB *next;
    struct PCB *prev;
    
} PCB;

/**
 Queue
 */
typedef struct QUEUE {
    int count;
    PCB *head;
    PCB *tail;
} QUEUE;

/**
 Suspends PCB
 */
int commSuspend();

/**
 Resumes PCB
 */
int commResume();

/**
 Set priority of PCB
 */
int commSetPriority();

/**
 Display name, class, states, and priority of PCB
 */
int commShowPCB();

/**
 Display info for PCBs in both queues
 */
int commShowAll();

/**
 Display info for PCBs in the ready queue
 */
int commShowReady();

/**
 Display info for PCBs in the blocked queue
 */
int commShowBlocked();

/**
 Create PCB
 */
int commCreatePCB();

/**
 Delete PCB
 */
int commDeletePCB();

/**
 Change state of PCB to blocked
 */
int commBlock();

/**
 Change state of PCB to unblocked
 */
int commUnblock();

/**
 Clear both PCB queues
 */
int commClearQueues();

/**
 Allocate memory for new PCB
 */
PCB* allocatePCB();

/**
 Free memory of PCB
 */
int freePCB(PCB * pcb);

/**
 Initialize PCB
 */
PCB* setupPCB(char* pcbName, int pcbClass, int priority);

/**
 Return specified PCB
 */
PCB* findPCB(char* pcbName);

/**
 Insert PCB into Ready Queue
 */
void insertPCB(PCB* pcb);

/**
 Display info for PCB
 */
void displayPCB(PCB* pcb);

/**
 Return string representation of PCB state
 */
char* strState(int state);

/**
 Return string representation of PCB class
 */
char* strClass(int pcbClass);

/**
 Return head of the Ready Queue
 */
PCB* getReadyProc();

/**
 Remove specified pcb
 */
int removePCB(PCB* pcb);

/**
 Handler for resume all function
 */
int commResumeAll();

/**
 Check if ready queue is empty
 */
int readyEmpty();

/**
 Check if blocked queue is empty
 */
int blockedEmpty();

QUEUE getHead();

/**
 Return head of the Blocked Queue
 */
PCB* getBlockedProc();

#endif
