#ifndef procr3_h
#define procr3_h

void proc1();
void proc2();
void proc3();
void proc4();
void proc5();

#endif
