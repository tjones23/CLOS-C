#ifndef _READINPUT_H
#define _READINPUT_H

#define ESCAPE '\33'
#define UP '[A'
#define DOWN '[B'
#define LEFT '[D'
#define RIGHT '[C'
#define BACKSPACE '\177'
#define DELETE '~'
#define NEW_LINE '\n'
#define RETURN '\r'

#define LOG_LIMIT 96

#include <system.h>

/*
   Polls input from the keyboard
*/
int serial_input(char * buffer, int * count);

#endif
