#ifndef _SHUTDOWN_H
#define _SHUTDOWN_H

/*
   Handles shutdown command
*/
int shutdownComm(void);

#endif
