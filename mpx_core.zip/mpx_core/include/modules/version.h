#ifndef _VERSION_H
#define _VERSION_H

/*
  Handles version command
*/
int versionComm(void);

#endif
