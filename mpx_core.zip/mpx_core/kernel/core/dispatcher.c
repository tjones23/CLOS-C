#include <system.h>
#include <string.h>
#include <core/dispatcher.h>
#include <core/io.h>
#include <core/serial.h>
#include <modules/context.h>
#include <modules/pcb.h>
#include "modules/mpx_supt.h"

PCB* loader(char *name, void (*func)(void)) {
    PCB *new_pcb = setupPCB(name, 1, 1);
    
    new_pcb->state = SUSPENDED;
    context *cp = (context*)(new_pcb->stackTop);
    memset(cp, 0, sizeof(context));
    cp->fs = 0x10;
    cp->gs = 0x10;
    cp->ds = 0x10;
    cp->es = 0x10;
    cp->cs = 0x8;
    cp->ebp = (u32int)(new_pcb->stackBase);
    cp->esp = (u32int)(new_pcb->stackTop);
    cp->eip = (u32int)func;
    cp->eflags = 0x202;
        
    return new_pcb;
}

void yield() {
    asm volatile("int $60");
}

void insertIdle() {
    PCB* idl = loader("idle", &idle);
    
    idl->priority = 0;
    idl->state = NOT_SUSPENDED;
    
    insertPCB(idl);
}
