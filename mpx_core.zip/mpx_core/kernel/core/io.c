#include <system.h>
#include <string.h>
#include <core/io.h>
#include <modules/pcb.h>
#include <modules/commhand.h>
#include "modules/mpx_supt.h"

/*
 Insert IOD into IOCB queue
 */
int enqueue(IOD *iod, IOCB *queue) {
    if(queue->count == 0) {
        queue->head = iod;
        queue->tail = iod;
        queue->count++;
    }
    else {
        queue->tail->next = iod;
        queue->tail = iod;
        queue->count++;
    }
    
    return CONTINUE;
}

/*
 Remove IOD from IOCB queue
 */
IOD *dequeue(IOCB *queue) {
    IOD *iod;
    iod = queue->head;
    
    if(queue->count == 1) {
        queue->head = NULL;
        queue->tail = NULL;
    }
    else {
        queue->head = queue->head->next;
    }
    
    queue->count--;
    
    return iod;
}

/*
 Initialize IOD
 */
IOD *setupIOD(char *name, PCB *pcb) {
    IOD *iod = NULL;
    iod = sys_alloc_mem(sizeof(IOD));
    iod->name = name;
    iod->process = pcb;
    iod->buffer = (char*) get_buffer();
    iod->count = (int*) get_count();
    iod->opCode = (int) get_op_code();
    return iod;
}

/*
 Initialize IOCB
 */
IOCB *setupIOCB(IOD *iod) {
    IOCB *iocb = NULL;
    iocb = sys_alloc_mem(sizeof(IOCB));
    iocb->count = 1;
    iocb->head = iod;
    iocb->head->buffer = iod->buffer;
    iocb->head->count = iod->count;
    return iocb;
}
