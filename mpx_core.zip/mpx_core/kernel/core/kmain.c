/*
----- kmain.c -----

Description..: Kernel main. The first function called after
the bootloader. Initialization of hardware, system
structures, devices, and initial processes happens here.
*/

#include <stdint.h>
#include <string.h>
#include <system.h>
#include <core/io.h>
#include <core/serial.h>
#include <core/tables.h>
#include <core/interrupts.h>
#include <core/dispatcher.h>
#include <mem/heap.h>
#include <mem/paging.h>
#include "modules/mpx_supt.h"
#include <modules/commhand.h>
#include <modules/read_input.h>
#include <modules/pcb.h>
#include <modules/mem_manager.h>
#include <modules/newTestProcs.h>

void kmain(void) {
    // extern uint32_t magic;
    // Uncomment if you want to access the multiboot header
    // extern void *mbd;
    // char *boot_loader_name = (char*)((long*)mbd)[16];
    
    // 0) Initialize Serial I/O and call mpx_init
    
    klogv("Starting MPX boot sequence...");
    klogv("Initialized serial I/O on COM1 device...");
    init_serial(0x3f8);
    set_serial_out(0x3f8);
    set_serial_in(0x3f8);
    // sys_set_read(serial_input);

    // 1) Initialize the support software by identifying the current
    //     MPX Module.  This will change with each module.
    
    mpx_init(IO_MODULE);
    mpx_init(MEM_MODULE);
    initHeap(50000);
    sys_set_malloc(&myAlloc);
    sys_set_free(&myFree);
    
    // 2) Check that the boot was successful and correct when using grub
    // Comment this when booting the kernel directly using QEMU, etc.
    // if ( magic != 0x2BADB002 ){
        // kpanic("Boot was not error free. Halting.");
    // }

    // 3) Descriptor Tables
    klogv("Initializing descriptor tables...");
    init_gdt();
    init_idt();

    klogv("Initializing program interrupt controller...");
    init_pic();

    klogv("Installing interrupt handlers for first 32 irq lines...");
    init_irq();

    // Enable interrupts
    sti();
    
    // 4) Virtual Memory
    klogv("Initializing virtual memory...");
    init_paging();
    
    // 5) Call YOUR command handler -  interface method
    klogv("Transferring control to commhand...");
    
    comOpen(setupDCB()->eventFlag, 1200);
    
    insertPCB(loader("com write", COMWRITE));
    insertPCB(loader("com read", COMREAD));
    insertPCB(loader("io com 25", IOCOM25));
    insertPCB(loader("io com", IOCOM));
    
    PCB *commhand = loader("commhand", &init_commhandler);
    commhand->priority = 9;
    commhand->state = NOT_SUSPENDED;
    insertPCB(commhand);
    insertIdle();
    yield();
    
    comClose();
    
    // 6) System Shutdown on return from your command handler
    klogv("Starting system shutdown procedure...");
    
    /* Shutdown Procedure */
    klogv("Shutdown complete. You may now turn off the machine. (QEMU: C-a x)");
    hlt();
}
