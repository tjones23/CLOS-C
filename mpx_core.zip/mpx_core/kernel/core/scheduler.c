#include <system.h>
#include <string.h>
#include <core/scheduler.h>
#include <core/io.h>
#include <core/serial.h>
#include <modules/pcb.h>
#include <modules/commhand.h>
#include "modules/mpx_supt.h"

#define PIC1 0x20

IOCB *queue;

/*
 I/O Scheduler
 */
void scheduler() {
    outb(PIC1+1,0xFF);
    
    PCB *cop = get_cop();
    IOD *iod = setupIOD(cop->pcbName, cop);
    
    if(queue == NULL) {
        queue = setupIOCB(iod);
    }
    
    if(enqueue(iod, queue)) {
        if(iod->opCode == READ) {
            commRead(iod->buffer, iod->count);
        }
        else if(iod->opCode == WRITE) {
            commWrite(iod->buffer, iod->count);
        }
    }
    
    cop->rrb = BLOCKED;
    insertPCB(cop);
}

/*
 Return IOCB queue
 */
IOCB *getIOCB() {
    return queue;
}
