/*
  ----- serial.c -----

  Description..: Contains methods and variables used for
    serial input and output.
*/

#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <system.h>
#include <core/scheduler.h>
#include <core/io.h>
#include <core/serial.h>
#include "modules/mpx_supt.h"
#include <modules/commhand.h>
#include <modules/read_input.h>

DCB *dcb;
char iochar = '\0';
u32int *prevFunc;

void disable() {
    outb(COM1+4, 0x00);
}

void enable() {
    outb(COM1+1, 0x0B);
}

u32int *getvect() {
    return prevFunc;
}

int setvect(int reg, u32int *handler){
    inb(reg);
    
    u32int *vect;
    
    vect = (u32int*) VEC_ADDR;
    prevFunc = vect;
    vect = (u32int*) handler;
    
    return NO_ERROR;
}

// Active devices used for serial I/O
int serial_port_out = 0;
int serial_port_in = 0;

/*
  Procedure..: init_serial
  Description..: Initializes devices for user interaction, logging, ...
*/
int init_serial(int device)
{
  outb(device + 1, 0x00); //disable interrupts
  outb(device + 3, 0x80); //set line control register
  outb(device + 0, 115200/9600); //set bsd least sig bit
  outb(device + 1, 0x00); //brd most significant bit
  outb(device + 3, 0x03); //lock divisor; 8bits, no parity, one stop
  outb(device + 2, 0xC7); //enable fifo, clear, 14byte threshold
  outb(device + 4, 0x0B); //enable interrupts, rts/dsr set
  (void)inb(device);      //read bit to reset port
  return NO_ERROR;
}

/*
  Procedure..: serial_println
  Description..: Writes a message to the active serial output device.
    Appends a newline character.
*/
int serial_println(const char *msg)
{
  int i;
  for(i=0; *(i+msg)!='\0'; i++){
    outb(serial_port_out,*(i+msg));
  }
  outb(serial_port_out,'\r');
  outb(serial_port_out,'\n');  
  return NO_ERROR;
}

/*
  Procedure..: serial_print
  Description..: Writes a message to the active serial output device.
*/
int serial_print(const char *msg)
{
  int i;
  for(i=0; *(i+msg)!='\0'; i++){
    outb(serial_port_out,*(i+msg));
  }
  if (*msg == '\r') outb(serial_port_out,'\n');
  return NO_ERROR;
}

/*
  Procedure..: set_serial_out
  Description..: Sets serial_port_out to the given device address.
    All serial output, such as that from serial_println, will be
    directed to this device.
*/
int set_serial_out(int device)
{
  serial_port_out = device;
  return NO_ERROR;
}

/*
  Procedure..: set_serial_in
  Description..: Sets serial_port_in to the given device address.
    All serial input, such as console input via a virtual machine,
    QEMU/Bochs/etc, will be directed to this device.
*/
int set_serial_in(int device)
{
  serial_port_in = device;
  return NO_ERROR;
}

/*
 I/O Module Read Function w/ helper
 */
int commRead(char *buffer, int *count) {
    
    if(dcb == NULL) {
        dcb = setupDCB();
    }
    
    if( (dcb->flag == OPENED) && (dcb->status == IDLE)  && (*dcb->eventFlag == SET)  ) {
        dcb->inBuffer = buffer;
        dcb->inCount = count;
        dcb->inSize = 0;
        dcb->status = READ;
        *dcb->eventFlag = RESET;

        sti();
        
        while(1) {
            if(inb(COM1 + 5) & 1) {
                iochar = inb(COM1);
                
                if (dcb->status == READ) {
                    
                    if(iochar == 'A' || iochar == 'B') {
                        int i;
                        for(i = 0; i < dcb->ringBufferIn-2; i++) {
                            outb(COM1, '\b');
                            outb(COM1, ' ');
                            outb(COM1, '\b');
                        }
                    }
                    else if (iochar == 'C') {
                        outb(COM1, iochar);
                    }
                    else if (iochar == 'D') {
                        outb(COM1, iochar);
                    }
                    else if (iochar == '\177') {
                        outb(COM1, '\b');
                        outb(COM1, ' ');
                        outb(COM1, '\b');
                        
                        dcb->ringBuffer[dcb->ringBufferIn--] = '\0';
                    }
                    else if (iochar == '\r') {
                        dcb->ringBuffer[dcb->ringBufferIn] = '\0';
                        dcb->status = IDLE;
                        *dcb->eventFlag = SET;
                        dcb->ringBufferCount = dcb->ringBufferIn;
                        dcb->ringBufferIn = 0;
                        outb(COM1, '\n');
                        return CONTINUE;
                    }
                    else {
                        dcb->ringBuffer[dcb->ringBufferIn] = iochar;
                        outb(COM1, dcb->ringBuffer[dcb->ringBufferIn++]);
                    }
                }
            }
       }
        
        while(dcb->ringBufferCount > 0) {
            dcb->inBuffer[dcb->inSize++] = dcb->ringBuffer[dcb->ringBufferOut];
            dcb->ringBuffer[dcb->ringBufferOut++] = '\0';
            dcb->ringBufferCount--;
        }
        dcb->ringBufferOut = 0;
        
        cli();
        
        dcb->inBuffer[dcb->inSize] = '\0';
        dcb->status = IDLE;
        *dcb->inCount = dcb->inSize;
        *dcb->eventFlag = SET;
    }
    
    return CONTINUE;
}

void readComm() {
    commRead(get_buffer(), get_count());
}

/*
 I/O Module Write Function w/ helper
 */
int commWrite(char *buffer, int *count) {
    if(dcb == NULL) {
        dcb = setupDCB();
    }
    
    if( (dcb->flag == OPENED) && (dcb->status == IDLE)  && (*dcb->eventFlag == SET) && (buffer != NULL) && (count != NULL) ) {
        dcb->outBuffer = buffer;
        dcb->outCount = count;
        dcb->outSize = 0;
        dcb->status = WRITE;
        *dcb->eventFlag = RESET;
                
        sti();
        
        while (dcb->outSize < *dcb->outCount) {
            iochar = dcb->outBuffer[dcb->outSize];
            dcb->outSize++;
            outb(COM1, iochar);
        }
        
        cli();
        
        int mask;
        mask = inb(INT_ENABLE);
        mask &= ~0x02;
        outb(INT_ENABLE, mask);
        
        sti();
        
        dcb->status = IDLE;
        *dcb->outCount = dcb->outSize;
        *dcb->eventFlag = SET;
    }
    
    return CONTINUE;
}

void writeComm() {
    commWrite(get_buffer(), get_count());
}

void intHandlerL2In() {
    readComm();
}

void intHandlerL2Out() {
    writeComm();
}

void intHandlerL2LS() {
    inb(LS_REG);
}

void intHandlerL2MS() {
    inb(MS_REG);
}

void intHandlerL1() {
    int type = 0;
    
    if (dcb->flag == OPENED) {
        type = inb(INT_ID_REG);
        type = type & 0x07;
        
        if (type == 0) {
            intHandlerL2MS();
        }
        else if (type == 2) {
            intHandlerL2Out();
        }
        else if (type == 4) {
            intHandlerL2In();
        }
        else if (type == 6) {
            intHandlerL2MS();
        }
    }
    
    outb(PIC_CMD, EOI);
}

/*
 
 */
int comOpen(int *eflag_p, int baud_rate) {
    if(dcb == NULL) {
        dcb = setupDCB();
    }
    
    int baud_rate_div;
    int mask;
    
    if (eflag_p == NULL) {
        return INV_EFLAG;
    }
    
    if (baud_rate <= 0) {
        return INV_BRD;
    }
    
    if (dcb->flag == OPENED) {
        return PORT_OPEN;
    }
    
    prevFunc = getvect(0x0c);
    setvect(0x0c, (u32int*) &intHandlerL1);
    
    baud_rate_div = 115200 / (long) baud_rate;
    
    outb(LC_REG, 0x80);
    outb(LSB, baud_rate_div & 0xFF);
    outb(MSB, (baud_rate_div >> 8) & 0xFF);
    outb(LC_REG, 0x03);
    
    cli();
    
    mask = inb(PIC_MASK);
    mask = mask & ~0x10;
    outb(PIC_MASK, mask);
    
    sti();
    
    outb(MC_REG, 0x08);
    outb(INT_ENABLE, 0x01);
    
    return NO_ERROR;
}

/*
 
 */
int comClose() {
    int mask;
    
    if (dcb->flag != OPENED) {
        return PORT_CLOSED;
    }
    
    dcb->flag = CLOSED;
    
    cli();
    
    mask = inb(PIC_MASK);
    mask = mask | 0x10;
    outb(PIC_MASK, mask);
    
    sti();
    
    outb(MC_REG, 0x00);
    outb(INT_ENABLE, 0x00);
    
    setvect(0x0c, prevFunc);
    
    return NO_ERROR;
}

/*
 Initialize DCB
 */
DCB *setupDCB() {
    DCB *newDCB = NULL;
    newDCB = sys_alloc_mem(sizeof(DCB));
    newDCB->flag = OPENED;
    newDCB->status = IDLE;
    *newDCB->eventFlag = SET;
    newDCB->ringBufferIn = 0;
    newDCB->ringBufferOut = 0;
    newDCB->ringBufferCount = 0;

    return newDCB;
}

/*
 Return DCB
 */
DCB *getDCB() {
    if(dcb == NULL) {
        dcb = setupDCB();
    }
    return dcb;
}
