#include <string.h>
#include <system.h>
#include <stddef.h>
#include <core/serial.h>
#include <core/io.h>
#include <core/dispatcher.h>
#include <core/scheduler.h>
#include <core/interrupts.h>
#include <modules/commhand.h>
#include <modules/mpx_supt.h>
#include <modules/pcb.h>
#include <modules/context.h>
#include <modules/newTestProcs.h>

#define PIC1 0x20
#define io_wait() asm volatile ("outb $0x80")

PCB *cop;
context *globalContext;

/*
  Procedure..: klogv
  Description..: Kernel log messages. Sent to active
      serial device.
*/
void klogv(const char *msg)
{
  char logmsg[64] = {'\0'}, prefix[] = "klogv: ";
  strcat(logmsg, prefix);
  strcat(logmsg, msg);
  serial_println(logmsg);
}

/*
  Procedure..: kpanic
  Description..: Kernel panic. Prints an error message
      and halts.
*/
void kpanic(const char *msg)
{
  cli(); //disable interrupts
  char logmsg[64] = {'\0'}, prefix[] = "Panic: ";
  strcat(logmsg, prefix);
  strcat(logmsg, msg);
  klogv(logmsg);
  hlt(); //halt
}

/*
 System Interrupt Handler
 */
u32int* sys_call(context *registers) {
    PCB *pcb = getReadyProc();
    IOD *iod;
    IOCB *iocb = getIOCB();
    
    if(iocb == NULL) {
        iocb = setupIOCB(setupIOD(pcb->pcbName, pcb));
    }
    
    if(*iocb->eventFlag == SET) {
        *iocb->eventFlag = RESET;
        iod = iocb->head;
        iocb->head = iocb->head->next;
        iocb->count--;
        iod->process->rrb = READY;
        iod = iod->next;
    }
        
    if (cop == NULL) {
        globalContext = registers;
    }
    else {
        if(get_op_code() == IDLE) {
            cop->stackTop = (unsigned char*) registers;
            cop->rrb = READY;
            insertPCB(cop);
        }
        else if (get_op_code() == EXIT) {
            freePCB(cop);
        }
        else if (get_op_code() == READ || get_op_code() == WRITE) {
            scheduler();
        }
    }
    
    if (pcb != NULL && getDCB()->flag == OPENED) {
        cop = pcb;
        removePCB(pcb);
        return (u32int*) cop->stackTop;
    }
        
    cop = NULL;
    
    
    return (u32int*) globalContext;
}

/*
 Return cop
 */
PCB *get_cop() {
    return cop;
}

/*
 Return globalContext
 */
context *get_globalContext() {
    return globalContext;
}

