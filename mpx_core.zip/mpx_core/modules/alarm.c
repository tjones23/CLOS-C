/*#include <system.h>
#include <string.h>
#include <core/serial.h>
#include <core/asm.h>
#include <core/io.h>
#include <modules/commhand.h>
#include <modules/help.h>
#include <modules/read_input.h>
#include "mpx_supt.h"
#include "pcb.h"
#include "date.c"


char output[MAX_BUFF];
int* mb = (int*) MAX_BUFF;

const char *time[20];
const char *message[20];


void alarmInput (int *t, char *m)
   {
      int i;
      for(i = 0; i < 20; i++)
         {
	    if(time[i] != NULL && message[i] == NULL)
            {
 		*time = &t;
                *message = &m;
	    }
            else
		continue;
         }

   }


void alarmPCB()
   {
      *char s1 = "alarm";
      setupPCB(s1,2,1);
      
      int i;
      *char s2 = getTime();
      for(i = 0; i < 20; i++)
         {
 	    
	    if(strcmp(time[i], s2) = 0) || strcmp(time[i], s2) > 0)
		{
  	   	    output = message[i];
		    sys_req(WRITE, COM1, output, mb);
   		    serial_println("");
   		    serial_println(output);
		    
		    time[i] = null;
                    message[i] = null;
		}
	 }

   }*/
