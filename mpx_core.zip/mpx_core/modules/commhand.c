#include <system.h>
#include <string.h>
#include <core/serial.h>
#include "mpx_supt.h"
#include <modules/commhand.h>
#include <modules/help.h>
#include <modules/shutdown.h>
#include <modules/version.h>
#include <modules/date.h>
#include <modules/read_input.h>
#include <modules/pcb.h>
#include <modules/dl_queue.h>
#include <modules/context.h>
#include <modules/procsr3.h>
#include <core/dispatcher.h>
#include <modules/mem_manager.h>
#include <modules/newTestProcs.h>

int commLoadr3(void) {
    insertPCB(loader("proc1", &proc1));
    serial_println("Proc1: Loaded");
    
    insertPCB(loader("proc2", &proc2));
    serial_println("Proc2: Loaded");
    
    insertPCB(loader("proc3", &proc3));
    serial_println("Proc3: Loaded");
    
    insertPCB(loader("proc4", &proc4));
    serial_println("Proc4: Loaded");
    
    insertPCB(loader("proc5", &proc5));
    serial_println("Proc5: Loaded");
    
    return CONTINUE;
}

int commYield() {
    yield();
    return CONTINUE;
}

int clear() {
    serial_println("\n\n\n\n\n\n\n\n\n\n");
    serial_println("\033[1;31m \nCommand Line: \033[0;32m \nhelp \nversion \nget date \nget time \nset date \nset time \nset alarm \nloadr3 \nyield \nresume all \nresume\033[0;35m:\033[0;34m name \033[0;32m \nsuspend\033[0;35m:\033[0;34m name \033[0;32m \nset priority\033[0;35m:\033[0;34m name priority \033[0;32m \nshow pcb\033[0;35m:\033[0;34m name \033[0;32m \nshow all \nshow ready \nshow blocked \nshow allocated \nshow free \nis empty \nshow heap \ninit heap \nfree mcb\033[0;35m:\033[0;34m mcb \033[0;32m \nallocate mcb\033[0;35m:\033[0;34m size \033[0;32m \nclear \nshutdown \n\033[0m");
    
    return CONTINUE;
}

/**
 Initialize command
 */
COMMAND init_command(char* info, int (*func)(void), char* help) {
    COMMAND comm;
    comm.info = info;
    comm.func = func;
    comm.help = help;
    return comm;
}

/**
   Initialize command handler
*/
void init_commhandler(void) {
    COMM_LIST[VERSION] = init_command("version", &versionComm, "Returns current sysetm version.");
    COMM_LIST[HELP] = init_command("help", &helpComm, "Displays information about using system commands.");
    COMM_LIST[SHUTDOWN] = init_command("shutdown", &shutdownComm, "Terminates all processes and exits the system.");
    COMM_LIST[GET_DATE] = init_command("get date", &commGetDate, "Displays the current system date");
    COMM_LIST[SET_DATE] = init_command("set date", &commSetDate, "Sets the system date.");
    COMM_LIST[GET_TIME] = init_command("get time", &commGetTime, "Displays the system time.");
    COMM_LIST[SET_TIME] = init_command("set time", &commSetTime, "Sets the system time.");
    COMM_LIST[SUSPEND] = init_command("suspend", &commSuspend, "Changes the state of the PCB to suspended.\nThe parameter must be a valid PCB name.");
    COMM_LIST[RESUME] = init_command("resume", &commResume, "Changes the state of the PCB to not suspended.\nThe parameter must be a valid PCB name.");
    COMM_LIST[SET_PRIORITY] = init_command("set priority", &commSetPriority, "Changes the priority of the PCB.\nThe parameters must be a valid PCB name, and a valid priority.");
    COMM_LIST[SHOW_PCB] = init_command("show pcb", &commShowPCB, "Displays meaningful information for the desired PCB.\nThe parameter must be a valid PCB name.");
    COMM_LIST[SHOW_ALL] = init_command("show all", &commShowAll, "Displays all PCBs in the system.");
    COMM_LIST[SHOW_READY] = init_command("show ready", &commShowReady, "Shows all PCBs in the ready queue.");
    COMM_LIST[SHOW_BLOCKED] = init_command("show blocked", &commShowBlocked, "Shows all PCBs in the blocked queue.");
    COMM_LIST[CREATE_PCB] = init_command("create pcb", NULL, "Creates a PCB.\nThe parameters must be a valid PCB name, class, and priority.");
    COMM_LIST[DELETE_PCB] = init_command("delete pcb", NULL, "Deletes a PCB.\nThe parameter must be a valid PCB name.\nThis is a temporary command.");
    COMM_LIST[BLOCK] = init_command("block", NULL, "Changes the state of a PCB to blocked.\nThe parameter must be a valid PCB name.\nThis is a temporary command.");
    COMM_LIST[UNBLOCK] = init_command("unblock", NULL, "Changes the state of a PCB to ready.");
    COMM_LIST[CLEARQUEUES] = init_command("clear queues", NULL, "Removes all PCB's from the queue.\nThere are no parameters for this command.");
    COMM_LIST[CLEAR] = init_command("clear", &clear, "Resets the command line.");
    COMM_LIST[YIELD] = init_command("yield", &commYield, "Yields control of the CPU to another process other than the command handler.");
    COMM_LIST[LOADR3] = init_command("loadr3", &commLoadr3, "Runs tests for R3.");
    COMM_LIST[RESUME_ALL] = init_command("resume all", &commResumeAll, "Changes the state of all PCB's to not suspended.");
    COMM_LIST[SET_ALARM] = init_command("set alarm", &commSetAlarm, "Sets an alarm for a specified date and time.");
    COMM_LIST[SHOW_ALLOCATED] = init_command("show allocated", &commPrintAllocated, "Prints all allocated MCBs in the heap.");
    COMM_LIST[SHOW_FREE] = init_command("show free", &commPrintFree, "Prints all free MCBs in the heap.");
    COMM_LIST[IS_EMPTY] = init_command("is empty", &commPrintIsEmpty, "Displays whether or not the heap is currently empty.");
    COMM_LIST[SHOW_HEAP] = init_command("show heap", &commPrintHeap, "Prints all MCBs in the heap.");
    COMM_LIST[INIT_HEAP] = init_command("init heap", &commInitHeap, "Initializes the heap.");
    COMM_LIST[FREE_MCB] = init_command("free mcb", &commFreeMCB, "Frees the memory space under the given address.");
    COMM_LIST[ALLOCATE_MCB] = init_command("allocate mcb", &commAllocateMCB, "Allocates previously freed memory.");

    serial_println("\n\n\n\n\n\n\n\n\n\n");
    serial_println("\033[1;31m \nWelcome to Team Gold OS!");
    serial_println("\033[1;31m \nCommand Line: \033[0;32m \nhelp \nversion \nget date \nget time \nset date \nset time \nset alarm \nloadr3 \nyield \nresume all \nresume\033[0;35m:\033[0;34m name \033[0;32m \nsuspend\033[0;35m:\033[0;34m name \033[0;32m \nset priority\033[0;35m:\033[0;34m name priority \033[0;32m \nshow pcb\033[0;35m:\033[0;34m name \033[0;32m \nshow all \nshow ready \nshow blocked \nshow allocated \nshow free \nis empty \nshow heap \ninit heap \nfree mcb\033[0;35m:\033[0;34m mcb \033[0;32m \nallocate mcb\033[0;35m:\033[0;34m size \033[0;32m \nclear \nshutdown \n\033[0m");
    
    char input[(int) MAX_BUFF];
    int *mb = (int*) MAX_BUFF;
    
    int i = 1;
    int j;
    while(i) {
         serial_print("$ ");
        
        sys_req(READ, COM1, input, mb);
                
        const char s[2] = ":";
        char *command = strtok(input, s);
        
        for(j = 0; j < COMM_COUNT; j++) {
            if(strcmp(command, COMM_LIST[j].info) == 0) {
                i = (int) COMM_LIST[j].func();
                break;
            }
        }
        
        if(command != NULL) {
            serial_print(command);
            serial_println("- Invalid command.");
        }
        
        serial_println("");
        
        sys_req(IDLE, DEFAULT_DEVICE, NULL, NULL);
    }
    
    sys_req(EXIT, DEFAULT_DEVICE, NULL, NULL);
}

