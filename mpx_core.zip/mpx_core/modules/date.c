#include <system.h>
#include <string.h>
#include <core/serial.h>
#include <core/asm.h>
#include <core/io.h>
#include <modules/commhand.h>
#include <modules/help.h>
#include <modules/read_input.h>
#include "mpx_supt.h"
#include <modules/pcb.h>

unsigned const char secLoc=0x00;
unsigned const char minLoc=0x02;
unsigned const char hrLoc=0x04;
unsigned const char dayLoc=0x07;
unsigned const char monthLoc=0x08;
unsigned const char yearLoc=0x09;
char output[MAX_BUFF];
int *mb = (int*) MAX_BUFF;
int alarmCount = 0;
int ahr, amin;
char *msg = '\0';
char *name = '\0';

/**********************************************************
 *   This function is used to conver BCD to decimal
 *   Paramaters: int BCD
 *
 *   Author: Corrie Shaffer
 ***********************************************************/
int BCDToDecimal(int BCD)
{
    if(BCD < 99)
        return (((BCD >> 4)*10) + (BCD & 0xF));
    else
        return (((BCD >> 16)*1000) + ((BCD >> 8)*100) +  ((BCD >> 4)*10) + (BCD & 0xF));
}

/**
 Returns the based raised to the power of the exponent
 */
int power(int base, int exponent) {
    int total=1;
    
    while(exponent > 0) {
        total *= base;
        exponent--;
    }
    
    return total;
}

/**********************************************************
 *   This function is used to get the current time from the RTC register
 *   Paramaters: int decimal
 *
 *   Author: Corrie Shaffer
 ***********************************************************/
void DecToBCD(int dec, unsigned char * buffer)
{
    int i=1;
    while(power(10, i) < dec) {
        i++;
    }
    
    if( ! (i & 0x01) ) {
        i--;
    }
    
    while(i > 0) {
        int i1 = dec / power(10, i);
        dec -= i1 * power(10, i--);
        
        int i2 = dec/ power(10, i);
        dec -= i2 * power(10, i--);
        
        *buffer++ = (((i1 & 0xff) << 4) | (i2 & 0xff));
    }
}

/**
 Helper methods for getTime, setTime, getDate and setDate
 */
unsigned char getSeconds() {
    outb(0x70, secLoc);
    unsigned char temp = (unsigned char) inb(0x71);
    return temp;
}

unsigned char getMinutes() {
    outb(0x70, minLoc);
    return (unsigned char) inb(0x71);
}

unsigned char getHours() {
    outb(0x70, hrLoc);
    return (unsigned char) inb(0x71);
}

unsigned char getDay() {
    outb(0x70, dayLoc);
    return (unsigned char) inb(0x71);
}

unsigned char getMonth() {
    outb(0x70, monthLoc);
    return (unsigned char) inb(0x71);
}

unsigned char getYear() {
    outb(0x70, yearLoc);
    return (unsigned char) inb(0x71);
}

void setSeconds(int num) {
    outb(0x70, secLoc);
    unsigned char temp[1];
    DecToBCD(num, temp);
    outb(0x71, temp[0]);
}

void setMinutes(int num) {
    outb(0x70, minLoc);
    unsigned char temp[1];
    DecToBCD(num, temp);
    outb(0x71, temp[0]);
}

void setHours(int num) {
    outb(0x70, hrLoc);
    unsigned char temp[1];
    DecToBCD(num, temp);
    outb(0x71, temp[0]);
}

void setDay(int num) {
    outb(0x70, dayLoc);
    unsigned char temp[1];
    DecToBCD(num, temp);
    outb(0x71, temp[0]);
}

void setMonth(int num) {
    outb(0x70, monthLoc);
    unsigned char temp[1];
    DecToBCD(num, temp);
    outb(0x71, temp[0]);
}

void setYear(int num) {
    outb(0x70, yearLoc);
    unsigned char temp[1];
    DecToBCD(num, temp);
    outb(0x71, temp[0]);
}

/**********************************************************
*   This function is used to get the current time from the RTC register
*   Paramaters: int hours, int minutes, int seconds
*
*   Author: Corrie Shaffer
***********************************************************/
void getTime() {
    strclr(output);
    
    int store;
    char *temp = ":";
    char temp2[MAX_BUFF];
    
    store = BCDToDecimal(getHours());
    if(store >= 10) itoa(store, temp2);
    else {
        temp2[0] = '0';
        temp2[1] = (store & 0xff) + '0';
        temp2[3] = '\0';
    }
    
    strcat(output, temp2);
    strcat(output, temp);
    
    store = BCDToDecimal(getMinutes());
    if(store >= 10) itoa(store, temp2);
    else {
        temp2[0] = '0';
        temp2[1] = (store & 0xff) + '0';
        temp2[3] = '\0';
    }
    
    strcat(output, temp2);
    strcat(output, temp);
    
    store = BCDToDecimal(getSeconds());
    if(store >= 10) itoa(store, temp2);
    else {
        temp2[0] = '0';
        temp2[1] = (store & 0xff) + '0';
        temp2[3] = '\0';
    }
    
    strcat(output, temp2);
}

/**
 Command handler getTime
 */
int commGetTime(void) {
    sys_req(WRITE, COM1, output, mb);

    getTime();
    
    serial_println("");
    serial_println(output);
    
    return CONTINUE;
}

/**********************************************************
*   This function is used to set the time to the RTC register
*   Paramaters: int hours, int mins, int secs
*
*   Author: Corrie Shaffer
***********************************************************/
void setTime(int hours, int minutes, int seconds) {
    if(hours>=24 || hours<0 || minutes<0 || minutes>=60 || seconds<0 || seconds>60) {
        serial_println("Invalid time.");
        return;
    }
    
    cli(); // disable interrupts
    
    setHours(hours);
    setMinutes(minutes);
    setSeconds(seconds);
    
    sti(); // enable interrupts
}


/*
 Set time function for command handler
 */
int commSetTime(void) {
    char buffer[(int) mb];
    int hr, min, sec;
    
    sys_req(READ, COM1, buffer, mb);
    
    serial_print("Enter hours- ");
    serial_input(buffer, mb);
    hr = atoi(buffer);
    
    serial_print("\nEnter minutes- ");
    serial_input(buffer, mb);
    min = atoi(buffer);
    
    serial_print("\nEnter seconds- ");
    serial_input(buffer, mb);
    sec = atoi(buffer);
    
    serial_println("");
    
    setTime(hr, min, sec);
    
    commGetTime();
    
    return CONTINUE;
}


/**********************************************************
*   This function is used to get the current date from the RTC register
*   Paramaters: int day, int month, int year
*
*   Author: Corrie Shaffer
***********************************************************/
void getDate() {
    strclr(output);
    
    int store;
    char *temp= "/";
    char temp2[MAX_BUFF];
    
    store = BCDToDecimal(getMonth());
    if(store >= 10) itoa(store, temp2);
    else {
        temp2[0] = '0';
        temp2[1] = (store & 0xff) + '0';
        temp2[3] = '\0';
    }
    strcat(output, temp2);
    strcat(output, temp);
    
    store = BCDToDecimal(getDay());
    if(store >= 10) itoa(store, temp2);
    else {
        temp2[0] = '0';
        temp2[1] = (store & 0xff) + '0';
        temp2[3] = '\0';
    }
    strcat(output, temp2);
    strcat(output, temp);
    
    store = BCDToDecimal(getYear());
    if(store >= 10) itoa(store, temp2);
    else {
        temp2[0] = '0';
        temp2[1] = (store & 0xff) + '0';
        temp2[3] = '\0';
    }
    strcat(output, temp2);
}

/**
 Command handler getDate
 */
int commGetDate(void) {
    sys_req(WRITE, COM1, output, mb);

    getDate();
    
    serial_println("");
    serial_println(output);
    
    return CONTINUE;
    
}

/**********************************************************
*   This function is used to set the date to the RTC register
*   Paramaters: int day, int month, int year
*
*   Author: Corrie Shaffer
***********************************************************/
void setDate(int d, int m, int y) {
    if(d<1 || m>12 || y<0 || y>99 || d<1 || d>31) {
        serial_println("Invalid date entered");
        return;
    }
    
    cli(); // disable interrupts
    
    setMonth(m);
    setDay(d);
    setYear(y);
    
    sti(); // enable interrupts
}

/*
 Command handler setDate()
 */
int commSetDate(void) {
    char buffer[(int) mb];
    int month, day, year;
    
    sys_req(READ, COM1, buffer, mb);
    
    serial_print("Enter month- ");
    serial_input(buffer, mb);
    month = atoi(buffer);
    
    serial_print("\nEnter day- ");
    serial_input(buffer, mb);
    day = atoi(buffer);
    
    serial_print("\nEnter year- ");
    serial_input(buffer, mb);
    year = atoi(buffer);
    
    serial_println("");
    
    setDate(day, month, year);
    
    commGetDate();
    
    return CONTINUE;
}

/**
 Alarm function with helpers
 */

void setAlarm() {
    int th = ahr;
    int tm = amin;
    char tmsg[(int) mb];
    tmsg[0] = '\0';
    strcpy(tmsg, msg);
    while(1) {
        int h = BCDToDecimal(getHours());
        int m = BCDToDecimal(getMinutes());
        
        if(h == th && m == tm) {
            serial_print("Alarm: ");
            serial_println(tmsg);
            serial_println("");
            
            sys_req(EXIT, DEFAULT_DEVICE, NULL, NULL);
        }
        
        sys_req(IDLE, DEFAULT_DEVICE, NULL, NULL);
    }
}

int commSetAlarm() {
    char buffer[(int) mb];
    sys_req(READ, COM1, buffer, mb);

    serial_print("Hours- ");
    serial_input(buffer, mb);
    ahr = atoi(buffer);
    
    serial_print("\nMinutes- ");
    serial_input(buffer, mb);
    amin = atoi(buffer);
    
    char buffer2[(int) mb];
    sys_req(READ, COM1, buffer2, mb);
    
    serial_print("\nAlarm Message- ");
    serial_input(buffer2, mb);
    msg = buffer2;
    
    serial_println("");
    
    alarmCount++;
    name = "alarm";
    name[5] = alarmCount;
    name[6] = '\0';
    
    insertPCB(loader(name, &setAlarm));
    PCB *pcb = findPCB(name);
    pcb->state = NOT_SUSPENDED;
    
    return CONTINUE;
}
