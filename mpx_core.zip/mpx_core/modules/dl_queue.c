#include <core/serial.h>
#include <string.h>
#include <modules/dl_queue.h>
#include <modules/commhand.h>
#include <modules/read_input.h>

QUEUE readyQueue = {.head = NULL, .tail = NULL, .count = 0};
QUEUE blockedQueue = {.head = NULL, .tail = NULL, .count = 0};

/**
 Insert PCB in queue in proper order
 */
/* void insertPCB(PCB* pcb) {
    if(pcb->rrb == READY) { // place into readyQueue
        if(readyQueue.count == 0) { // If the queue is empty
            readyQueue.head = readyQueue.tail = pcb;
            pcb->next = NULL;
            pcb->prev = NULL;
            readyQueue.count++;
            return;
        }
        else {
            PCB* curr = readyQueue.head;
            
            if(pcb->priority > curr->priority) { // If its priority is greater than head
                readyQueue.head = pcb;
                pcb->next = curr;
                curr->prev = pcb;
                readyQueue.count++;
                return;
            }
            
            curr = curr->next;
            
            while(curr) { // Place it given its priority within the queue
                if(pcb->priority > curr->priority) {
                    curr->prev->next = pcb;
                    pcb->prev = curr->prev;
                    pcb->next = curr;
                    curr->prev = pcb;
                    readyQueue.count++;
                    return;
                }
                curr = curr->next;
            }
            
            // If pcb is the lowest priority, place it at the tail
            curr = readyQueue.tail;
            curr->next = pcb;
            pcb->prev = curr;
            pcb->next = NULL;
            readyQueue.tail = pcb;
            readyQueue.count++;
            return;
        }
    }
    else if(pcb->rrb == BLOCKED) { //place into blockedQueue
        
        if(blockedQueue.count == 0) { // If the queue is empty
            blockedQueue.head = blockedQueue.tail = pcb;
            pcb->next = NULL;
            pcb->prev = NULL;
            blockedQueue.count++;
            return;
        }
        
        else { // The queue is not empty...insert at tail (FIFO)
            blockedQueue.tail->next = pcb;
            pcb->prev = blockedQueue.tail;
            pcb->next = NULL;
            blockedQueue.tail = pcb;
            blockedQueue.count++;
            return;
        }
    }
    else { //The state is unkown
        return;
    }
} */

/**
 Search both queues for PCB
 */
/* PCB* findPCB(char* pcbName) {
    PCB* curr = readyQueue.head; // search ready queue first

    while(curr) {
        if(strcmp(pcbName, curr->pcbName) == 0) {
            return curr;
        }
        curr = curr->next;
    }
    
    curr = blockedQueue.head; // search blocked queue second
    
    while(curr) {
        if(strcmp(pcbName, curr->pcbName) == 0) {
            return curr;
        }
        curr=curr->next;
    }
    
    return NULL;
} */

/**
 Remove PCB
 */
/* int removePCB(PCB* pcb) {
    if(pcb->rrb == READY) { // remove from readyQueue
        if(readyQueue.head == pcb && readyQueue.tail == pcb) {
            readyQueue.head = readyQueue.tail = NULL;
        }
        else if(readyQueue.head == pcb) {
            readyQueue.head = pcb->next;
            readyQueue.head->prev = NULL;
        }
        else if(readyQueue.tail == pcb) {
            readyQueue.tail = pcb->prev;
            readyQueue.tail->next = NULL;
        }
        else {
            pcb->next->prev = pcb->prev;
            pcb->prev->next = pcb->next;
        }
        readyQueue.count--;
    }
    else if(pcb->rrb == BLOCKED) { // remove from blocked
        if(blockedQueue.head == pcb && blockedQueue.tail == pcb) {
            blockedQueue.head = blockedQueue.tail = NULL;
        }
        else if(blockedQueue.head == pcb) {
            blockedQueue.head = pcb->next;
            blockedQueue.head->prev = NULL;
        }
        else if(blockedQueue.tail == pcb) {
            blockedQueue.tail = pcb->prev;
            blockedQueue.tail->next = NULL;
        }
        else {
            pcb->next->prev = pcb->prev;
            pcb->prev->next = pcb->next;
        }
        blockedQueue.count--;
    }
    else { // The state is unkown
        return ERROR;
    }
    pcb->next=NULL;
    pcb->prev=NULL;
    return CONTINUE;
} */

/**
 Print PCBs in both queues
 */
/* void printQueues() {
    serial_println("Ready Queue: ");
    PCB* pcb = readyQueue.head;
    
    while(pcb) {
        char temp1[5] = "";
        serial_print("\tPCB Name: ");
        serial_println(pcb->pcbName);
        strclr(temp1);
    
        serial_print("\tClass: ");
        itoa(pcb->pcbClass, temp1);
        serial_println(temp1);
        strclr(temp1);
    
        serial_print("\tPrio: ");
        itoa(pcb->pcbClass, temp1);
        serial_println(temp1);
        strclr(temp1);
    
        serial_print("\trrb: ");
        itoa(pcb->pcbClass, temp1);
        serial_println(temp1);
        strclr(temp1);
    
        serial_print("\tsus: ");
        itoa(pcb->pcbClass, temp1);
        serial_println(temp1);
        strclr(temp1);
    
        pcb = pcb->next;
    }
    
    serial_println("Blocked Queue:");
    pcb = blockedQueue.head;
    
    while(pcb) {
        char temp2[5] = "";
        serial_print("\tPCB Name: ");
        serial_println(pcb->pcbName);
        strclr(temp2);
    
        serial_print("\tClass: ");
        itoa(pcb->pcbClass, temp2);
        serial_println(temp2);
        strclr(temp2);
    
        serial_print("\tPrio: ");
        itoa(pcb->pcbClass, temp2);
        serial_println(temp2);
        strclr(temp2);
    
        serial_print("\trrb: ");
        itoa(pcb->pcbClass, temp2);
        serial_println(temp2);
        strclr(temp2);
    
        serial_print("\tsus: ");
        itoa(pcb->pcbClass, temp2);
        serial_println(temp2);
        strclr(temp2);
    
        pcb = pcb->next;
    }
} */

