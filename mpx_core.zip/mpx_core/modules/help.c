#include <modules/help.h>
#include <modules/commhand.h>
#include <modules/read_input.h>
#include <core/serial.h>
#include <string.h>
#include <system.h>
#include "mpx_supt.h"

//  Function for help command
int helpComm(void) {
    char * in = '\0';
    int * mb = (int*) MAX_BUFF;
    
    serial_println("\033[1;31m \nhelp: \033[0;32m \nversion \nget date \nget time \nset date \nset time \nset alarm \nloadr3 \nyield \nresume all \nresume \nsuspend \nset priority \nshow pcb \nshow all \nshow ready \nshow blocked \nshow allocated \nshow free \nis empty \nshow heap \ninit heap \nfree mcb \nallocate mcb \nclear \nshutdown \n\033[0m");
    
    serial_print("$ help: ");
    sys_req(READ, COM1, in, mb);
    serial_input(in, mb);
    serial_println("");
    
    char * comm = '\0';
    strcpy(comm, in);
	
    int i;
	for(i=0; i<COMM_COUNT; i++) {
		if(strcmp(comm, COMM_LIST[i].info) == 0) {
			serial_println(COMM_LIST[i].help);
			return CONTINUE;
		}
	}
	
	serial_print("help: ");
	serial_print(comm);
	serial_print("- Not Found\n");

	return CONTINUE;
}
