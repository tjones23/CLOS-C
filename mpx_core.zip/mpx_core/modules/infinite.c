#include <system.h>
#include <string.h>
#include <core/serial.h>
#include <core/asm.h>
#include <core/io.h>
#include <modules/commhand.h>
#include <modules/help.h>
#include <modules/read_input.h>
#include <modules/
#include "mpx_supt.h"


int mb = MAX_BUFF;

void infinite() {
    setupPCB(s1,9,2);
    
    while(1) {
        idle();
        sys_req(WRITE, COM1, "Infinte Process Running", *mb);
    }
}
