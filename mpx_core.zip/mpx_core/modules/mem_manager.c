#include <modules/mem_manager.h>
#include <modules/commhand.h>
#include <core/dispatcher.h>
#include "mpx_supt.h"

void printBlock(MCB *curr);
int isEmpty();
int compareMCB(MCB *m1, MCB *m2);
u32int shiftMCB(u32int ptr, int shift);
u32int getUsableAddress(MCB *mcb);
u32int relativeAddress(u32int mcb);
MCB *heapPrevFree(MCB *mcb);
MCB *heapPrevAllocated(MCB *mcb);
MCB *heapPrevMCB(MCB *mcb);
MCB *heapNextFree(MCB *mcb);
MCB *heapNextAllocated(MCB *mcb);
MCB *heapNextMCB(MCB *mcb);
void fillMCB(MCB *mcb, int type, int size, u32int addr, char *name, MCB *next, MCB *prev);
MCB *findMCB(u32int addr);
MCB *findParent(u32int p);
void insertFreeMCB(MCB *mcb);
void insertAllocatedMCB(MCB *mcb);
void insertMCB(MCB *mcb);
void removeFreeMCB(MCB *mcb);
void removeAllocatedMCB(MCB *mcb);
void removeMCB(MCB *mcb);
int initHeap(int size);
u32int myAlloc(u32int size);
int myFree(void *p);
int commFreeMCB();
int commInitHeap();
int commAllocateMCB();
int commPrintAllocated();
int commPrintFree();
int commPrintIsEmpty();
int commPrintHeap();

List freeBlocks;
List allocatedBlocks;
u32int heapStart;
u32int heapEnd;

void printBlock(MCB *curr) {
    serial_print("\tName\t:  ");
    serial_println(curr->name);
    serial_print("\tSize\t:  ");
    char size[6];
    size[5] = '\0';
    itoa(curr->size, size);
    serial_println(size);
    serial_println("");
}

int isEmpty() {
    return allocatedBlocks.head == NULL;
}

int compareMCB(MCB *m1, MCB *m2) {
    int c = m1->addr - m2->addr;
    return c;
}

u32int shiftMCB(u32int mcb, int shift) {
    u32int ptr = mcb;
    ptr += shift;
    return ptr;
}

u32int getUsableAddress(MCB *mcb) {
    u32int addr = (u32int) mcb;
    
    int i;
    for(i = 0; i < (int) sizeof(MCB); i++) {
        addr++;
    }
    
    return (u32int) addr;
}

u32int relativeAddress(u32int mcb) {
    return mcb;
}

MCB *heapPrevFree(MCB *mcb) {
    MCB *prev = NULL;
    MCB *curr = freeBlocks.head;
    
    while(curr) {
        if(curr > mcb) {
            break;
        }
        prev = curr;
        curr = curr->next;
    }
    
    return prev;
}

MCB *heapPrevAllocated(MCB *mcb) {
    MCB *prev = NULL;
    MCB *curr = allocatedBlocks.head;
    
    while(curr) {
        if(curr > mcb) {
            break;
        }
        prev = curr;
        curr = curr->next;
    }
    
    return prev;
}

MCB *heapPrevMCB(MCB *mcb) {
    MCB *fmcb = mcb->prev;
    MCB *amcb = heapPrevAllocated(mcb);
    
    if(!fmcb) {
        return amcb;
    }
    
    if(!amcb) {
        return fmcb;
    }
    
    return fmcb > amcb ? fmcb : amcb;
}

MCB *heapNextFree(MCB *mcb) {
    MCB *curr = freeBlocks.head;
    
    while(curr) {
        if(curr < mcb) {
            if(curr->next && curr->next > mcb) {
                return curr;
            }
        }
        curr = curr->next;
    }
    
    return NULL;
}

MCB *heapNextAllocated(MCB *mcb) {
    MCB *curr = allocatedBlocks.head;
    
    while(curr) {
        if(curr < mcb) {
            if(curr->next && curr->next > mcb) {
                return curr;
            }
        }
        curr = curr->next;
    }
    
    return NULL;
}

MCB *heapNextMCB(MCB *mcb) {
    MCB *fmcb = mcb->next;
    MCB *amcb = heapNextAllocated(mcb);
    
    if(!fmcb) {
        return amcb;
    }
    
    if(!amcb) {
        return fmcb;
    }
    
    return fmcb < amcb ? fmcb : amcb;
}

void fillMCB(MCB *mcb, int type, int size, u32int addr, char *name, MCB *next, MCB *prev) {
    mcb->type = type;
    mcb->size = size;
    mcb->addr = addr;
    mcb->name = name;
    mcb->next = next;
    mcb->prev = prev;
}

MCB *findMCB(u32int addr) {
    MCB* curr = allocatedBlocks.head;
    while(curr) {
        if(compareMCB(curr, (MCB*) addr) == 0) {
            return curr;
        }
        curr = curr->next;
    }
    
    return NULL;
}

MCB *findParent(u32int p) {
    u32int parentAddr = shiftMCB(p, -1 * sizeof(MCB));
    return findMCB(parentAddr);
}

void insertFree(MCB *mcb) {
    MCB* curr;
    
    if(freeBlocks.head == NULL) {
        freeBlocks.head = mcb;
    }
    else if(mcb < freeBlocks.head) {
        freeBlocks.head->prev = mcb;
        mcb->next = freeBlocks.head;
        freeBlocks.head = mcb;
    }
    else {
        curr = freeBlocks.head;
        while(curr->next != NULL) {
            if(mcb < curr) {
                mcb->prev = curr->prev;
                mcb->prev->next = mcb;
                mcb->next = curr;
                curr->prev = mcb;
                return;
            }
            curr = curr->next;
        }
        if(mcb < curr) {
            mcb->prev = curr->prev;
            mcb->prev->next = mcb;
            mcb->next = curr;
            curr->prev = mcb;
        }
        else {
            curr->next = mcb;
            mcb->prev = curr;
        }
    }
}

void insertAllocated(MCB *mcb) {
    MCB* curr;
    
    if(allocatedBlocks.head == NULL) {
        allocatedBlocks.head = mcb;
    }
    else if(mcb < allocatedBlocks.head) {
        allocatedBlocks.head->prev = mcb;
        mcb->next = allocatedBlocks.head;
        allocatedBlocks.head = mcb;
    }
    else {
        curr = allocatedBlocks.head;
        while(curr->next != NULL) {
            if(mcb < curr) {
                mcb->prev = curr->prev;
                mcb->prev->next = mcb;
                mcb->next = curr;
                curr->prev = mcb;
                return;
            }
            curr = curr->next;
        }
        if(mcb < curr) {
            mcb->prev = curr->prev;
            mcb->prev->next = mcb;
            mcb->next = curr;
            curr->prev = mcb;
        }
        else {
            curr->next = mcb;
            mcb->prev = curr;
        }
    }
}

void insertMCB(MCB *mcb) {
    if(mcb->type == FREE) {
        insertFree(mcb);
    }
    else if(mcb->type == ALLOCATED) {
        insertAllocated(mcb);
    }
    else {
        return;
    }
}

void removeFreeMCB(MCB *mcb) {
    if(compareMCB(mcb, freeBlocks.head) == 0) {
        if(freeBlocks.head->next) {
            freeBlocks.head = freeBlocks.head->next;
            freeBlocks.head->prev = NULL;
        }
        else {
            freeBlocks.head = NULL;
        }
    }
    else if(mcb->next == NULL) {
        mcb->prev->next = NULL;
    }
    else {
        mcb->prev->next = mcb->next;
        mcb->next->prev = mcb->prev;
    }
}

void removeAllocatedMCB(MCB *mcb) {
    if(compareMCB(mcb, allocatedBlocks.head) == 0) {
        if(allocatedBlocks.head->next) {
            allocatedBlocks.head = allocatedBlocks.head->next;
            allocatedBlocks.head->prev = NULL;
        }
        else {
            allocatedBlocks.head = NULL;
        }
    }
    else if(mcb->next == NULL) {
        mcb->prev->next = NULL;
    }
    else {
        mcb->prev->next = mcb->next;
        mcb->next->prev = mcb->prev;
    }
}

void removeMCB(MCB *mcb){
    if(mcb->type == FREE) {
        removeFreeMCB(mcb);
    }
    else if(mcb->type == ALLOCATED) {
        removeAllocatedMCB(mcb);
    }
    else {
        return;
    }
}

u32int myAlloc(u32int size) {
    if(size < 1) {
        return 0;
    }
    
    int tempSize = (int) size;
    int required = tempSize + (int) sizeof(MCB);
    int s;
    
    MCB *curr = freeBlocks.head;
    while(curr) {
        if(curr->size >= required) {
            s = curr->size;
            break;
        }
        curr = curr->next;
    }
    
    if(!curr) {
        serial_println("Error - Allocation too large");
        return ERROR;
    }
    
    removeMCB(curr);
    
    MCB *amcb = curr;
    if((curr->size - required) < (int) sizeof(MCB)) {
        required = curr->size;
        fillMCB(amcb, ALLOCATED, required, getUsableAddress(amcb), NULL, NULL, NULL);
        insertMCB(amcb);
    }
    else {
        fillMCB(amcb, ALLOCATED, required, getUsableAddress(amcb), NULL, NULL, NULL);
        insertMCB(amcb);
        
        MCB *fmcb = amcb;
        fmcb = (MCB*) shiftMCB((u32int) fmcb, required);
        int fmcbSize = s - amcb->size;
        fillMCB(fmcb, FREE, fmcbSize, getUsableAddress(fmcb), "Excess Free Block", NULL, NULL);
        insertMCB(fmcb);
    }
    
    return (u32int) amcb->addr;
}

int myFree(void *p) {
    MCB *mcb = findParent((u32int) p);
    
    if(!mcb) {
        return ERROR;
    }
    
    int s = mcb->size;
    u32int usableAddr = getUsableAddress(mcb);
    
    removeMCB(mcb);
    fillMCB(mcb, FREE, s, usableAddr, "Free Block", NULL, NULL);
    insertMCB(mcb);
    
    MCB *prev = heapPrevMCB(mcb);
    MCB *next = heapNextMCB(mcb);
    MCB *nmcb = mcb;
    
    if(prev && prev != mcb && prev->type == FREE) {
        removeMCB(mcb);
        nmcb = prev;
        s += prev->size;
    }
    
    if(next && next != mcb && next->type == FREE) {
        removeMCB(next);
        s += next->size;
    }
    
    if(s != mcb->size) {
        removeMCB(mcb);
        fillMCB(nmcb, FREE, s, getUsableAddress(nmcb), "Free Block", NULL, NULL);
        insertMCB(mcb);
    }
    
    return 0;
}

int initHeap(int size) {
    int adjustedSize = size + sizeof(MCB);
    while(adjustedSize % (sizeof(unsigned char *) != 0)) {
        adjustedSize++;
    }
    
    heapStart = kmalloc(adjustedSize);
    if(!heapStart) {
        return -1;
    }
    
    MCB *head = (MCB*) heapStart;
    fillMCB(head, FREE, adjustedSize, getUsableAddress(head), "Initial Free Block", NULL, NULL);
    heapEnd = shiftMCB(heapStart, head->size);
    insertMCB(head);
    allocatedBlocks.head = NULL;
    
    return adjustedSize;
}

int commFreeMCB() {
    void *p = (void *) strtok(NULL, " ");
    
    if(p == NULL) {
        serial_println("Free MCB: Too few arguments");
        return CONTINUE;
    }
    
    int result = myFree(p);
    
    if(result == 0) {
        serial_println("Free Failed: The specified MCB is incapable of being freed.");
    }
    else {
        serial_println("The MCB has been freed successfully.");
    }
    
    return CONTINUE;
}

int commInitHeap() {
    int HEAP_SIZE = 50000;
    
    if(initHeap(HEAP_SIZE)) {
        serial_println("The heap has been initialized successfully.");
        serial_print("\tSize\t:  ");
        char temp[6];
        temp[5] = '\0';
        itoa(HEAP_SIZE, temp);
        serial_println(temp);
    }
    else {
        serial_println("Heap allocation failed.");
    }
    
    return CONTINUE;
}

int commAllocateMCB() {
    char* s = strtok(NULL, " ");
    
    if(s == NULL) {
        serial_println("Allocate MCB: Too few arguments");
        return CONTINUE;
    }
    
    int size = atoi(s) + (int) heapStart;
    u32int result = myAlloc(size);
    
    if((int) result == ERROR_REQUEST_TOO_SMALL) {
        serial_println("Allocation Failed: The requested size was too small");
    }
    else if((int) result == ERROR_SPACE_UNAVAILABLE) {
        serial_println("Allocation Failed: Insufficient free space");
    }
    else {
        serial_println("The allocation completed successfully.");
    }
    
    return CONTINUE;
}

int commPrintAllocated() {
    serial_println("Allocated:");
    
    MCB* curr = allocatedBlocks.head;
    MCB* prev = NULL;
    
    while(curr && curr->type == ALLOCATED && prev != curr) {
        serial_print("\tName\t:  ");
        serial_println(curr->name);
        serial_print("\tSize\t:  ");
        char size[5];
        size[4] = '\0';
        itoa(curr->size, size);
        serial_println(size);
        serial_println("");
        
        prev = curr;
        curr = curr->next;
    }
    
    serial_println("");
    
    return CONTINUE;
}

int commPrintFree() {
    serial_println("Free:");
    
    MCB* curr = freeBlocks.head;
    MCB* prev = NULL;
    
    while(curr && curr->type == FREE && prev != curr) {
        printBlock(curr);
        prev = curr;
        curr = curr->next;
    }
    
    serial_println("");
    
    return CONTINUE;
}

int commPrintIsEmpty() {
    if(isEmpty()) {
        serial_println("The heap is empty.");
    }
    else {
        serial_println("The heap is not empty.");
    }
    
    return CONTINUE;
}

int commPrintHeap() {
    commPrintAllocated();
    commPrintFree();
    return CONTINUE;
}

int main();
