#include "mpx_supt.h"
#include <system.h>
#include <string.h>
#include <core/serial.h>
#include <core/asm.h>
#include <core/io.h>
#include <modules/commhand.h>
#include <modules/help.h>
#include <modules/read_input.h>
#include <mem/heap.h>
#include <modules/pcb.h>
// #include <modules/dl_queue.h>
#include <modules/context.h>
#include <core/dispatcher.h>

#define SYSTEM 1
#define APPLICATION 2

int commSuspend();
int commResume();
int commSetPriority();
int commShowPCB();
int commShowAll();
int commShowReady();
int commShowBlocked();
int commCreatePCB();
int commDeletePCB();
int commBlock();
int commUnblock();
int commClearQueues();
PCB* allocatePCB();
int freePCB(PCB * pcb);
PCB* setupPCB(char* pcbName, int pcbClass, int priority);
void displayPCB(PCB* pcb);
char* strState(int state);
char* strClass(int pcbClass);
PCB* getReadyProc();

QUEUE readyQueue;
QUEUE blockedQueue;

/**
 Insert PCB in queue in proper order
 */
void insertPCB(PCB* pcb) {
    if(findPCB(pcb->pcbName) != NULL) {
        return;
    }
    if(pcb->rrb == READY) {
        if(readyQueue.count == 0) {
            readyQueue.head = readyQueue.tail = pcb;
            pcb->next = NULL;
            pcb->prev = NULL;
            readyQueue.count++;
            return;
        }
        else {
            PCB* curr = readyQueue.head;
            if(pcb->priority > curr->priority) {
                readyQueue.head = pcb;
                pcb->next = curr;
                curr->prev = pcb;
                readyQueue.count++;
                return;
            }
            
            curr = curr->next;
            while(curr) {
                if(pcb->priority > curr->priority) {
                    curr->prev->next = pcb;
                    pcb->prev = curr->prev;
                    pcb->next = curr;
                    curr->prev = pcb;
                    readyQueue.count++;
                    return;
                }
                curr = curr->next;
            }
            
            curr = readyQueue.tail;
            curr->next = pcb;
            pcb->prev = curr;
            pcb->next = NULL;
            readyQueue.tail = pcb;
            readyQueue.count++;
            return;
        }
    }
    else if(pcb->rrb == BLOCKED) {
        if(blockedQueue.count == 0) {
            blockedQueue.head = blockedQueue.tail = pcb;
            pcb->next = NULL;
            pcb->prev = NULL;
            blockedQueue.count++;
            return;
        }
        else {
            blockedQueue.tail->next = pcb;
            pcb->prev = blockedQueue.tail;
            pcb->next = NULL;
            blockedQueue.tail = pcb;
            blockedQueue.count++;
            return;
        }
    }
    else {
        return;
    }
}

/**
 Search both queues for PCB
 */
PCB* findPCB(char* pcbName) {
    PCB* curr = readyQueue.head;
    while(curr){
        if(strcmp(pcbName, curr->pcbName) == 0) {
            return curr;
        }
        curr = curr->next;
    }
    
    curr = blockedQueue.head;
    while(curr){
        if(strcmp(pcbName, curr->pcbName) == 0) {
            return curr;
        }
        curr=curr->next;
    }
    
    return NULL;
}

/**
 Remove PCB
 */
int removePCB(PCB* pcb) {
    if(pcb->rrb == READY) {
        if(readyQueue.head == pcb && readyQueue.tail == pcb) {
            readyQueue.head = readyQueue.tail = NULL;
        }
        else if(readyQueue.head == pcb) {
            readyQueue.head = pcb->next;
            readyQueue.head->prev = NULL;
        }
        else if(readyQueue.tail == pcb) {
            readyQueue.tail = pcb->prev;
            readyQueue.tail->next = NULL;
        }
        else {
            pcb->next->prev = pcb->prev;
            pcb->prev->next = pcb->next;
        }
        readyQueue.count--;
    }
    else if(pcb->rrb == BLOCKED) {
        if(blockedQueue.head == pcb && blockedQueue.tail == pcb) {
            blockedQueue.head = blockedQueue.tail = NULL;
        }
        else if(blockedQueue.head == pcb) {
            blockedQueue.head = pcb->next;
            blockedQueue.head->prev = NULL;
        }
        else if(blockedQueue.tail == pcb) {
            blockedQueue.tail = pcb->prev;
            blockedQueue.tail->next = NULL;
        }
        else {
            pcb->next->prev = pcb->prev;
            pcb->prev->next = pcb->next;
        }
        blockedQueue.count--;
    }
    else {
        return ERROR;
    }
    
    pcb->next=NULL;
    pcb->prev=NULL;
        
    return CONTINUE;
}

/**
 Allocate memory for new PCB
 */
PCB* allocatePCB() {
    PCB *pcb = (PCB *) sys_alloc_mem(sizeof(PCB));
    pcb->stackTop = pcb->stackBase + 1024 - sizeof(context);
    return pcb;
}

/**
 Free memory of PCB
 */
int freePCB(PCB *pcb) {
    if(sys_free_mem(pcb) == -1) return CONTINUE;
    
    return ERROR;
}

/**
 Initialize PCB
 */
PCB* setupPCB(char* pcbName, int pcbClass, int priority) {
    struct PCB* pcb = allocatePCB();
    
    if(pcb == NULL) {
        return NULL;
    }
    
    strcpy(pcb->pcbName, pcbName);
    pcb->pcbName[20] = '\0';
    pcb->pcbClass = pcbClass;
    pcb->priority = priority;
    pcb->state = NOT_SUSPENDED;
    pcb->rrb = READY;
    
    return pcb;
}

/**
 Display info for PCB
 */
void displayPCB(PCB* pcb) {
    char temp[2];
    temp[1] = '\0';
    
    serial_print("\tPCB\t:  ");
    serial_println(pcb->pcbName);
    
    serial_print("\tClass\t:  ");
    serial_println(strClass((int) pcb->pcbClass));
    
    serial_print("\tState\t:  ");
    serial_println(strState((int) pcb->state));
    
    temp[0] = (char) pcb->priority + 48;
    
    serial_print("\tPriority:  ");
    serial_println(temp);
    serial_println("");
}

/**
 Return string representation of PCB state
 */
char *strState(int state) {
    if(state == SUSPENDED) {
        return "Suspended";
    }
    
    else if(state == NOT_SUSPENDED) {
        return "Not Suspended";
    }
    
    return "ERROR";
}

/**
 Return string representation of PCB class
 */
char *strClass(int pcbClass) {
    if(pcbClass == SYSTEM) {
        return "System";
    }
    
    else if(pcbClass == APPLICATION) {
        return "Application";
    }
    
    return "ERROR";
}

/**
 Return head of the Ready Queue
 */
PCB* getReadyProc() {
    PCB* curr = readyQueue.head;
    
    while(curr) {
        if(curr->state == NOT_SUSPENDED) return curr;
        curr = curr->next;
    }
    
    return NULL;
}

/**
 Return head of the Blocked Queue
 */
PCB* getBlockedProc() {
    PCB* curr = blockedQueue.head;
    
    while(curr) {
        if(curr->state == NOT_SUSPENDED) return curr;
        curr = curr->next;
    }
    
    return NULL;
}

QUEUE getHead() {
    QUEUE curr = readyQueue;
    return curr;
}

/**
 Suspends PCB
 */
int commSuspend() {
    char* name = strtok(NULL, " ");
    
    if(name == NULL) {
        serial_println("Error: Invalid Parameters");
        return ERROR;
    }
    
    PCB* pcb = findPCB(name);
    
    if(pcb == NULL) {
        serial_println("Error: A PCB of that name does not exist.");
        return ERROR;
    }
    
    pcb->state = SUSPENDED;
    
    displayPCB(pcb);
    
    return CONTINUE;
}

/**
 Resumes PCB
 */
int commResume() {
    char* name = strtok(NULL, " ");
    
    if(name == NULL) {
        serial_println("Error: Invalid Parameters");
        return ERROR;
    }
    
    PCB* pcb = findPCB(name);
    
    if(pcb == NULL) {
        serial_println("Error: A PCB of that name does not exist.");
        return ERROR;
    }
    
    pcb->state = NOT_SUSPENDED;
    
    displayPCB(pcb);
    
    return CONTINUE;
}

/**
 Set priority of PCB
 */
int commSetPriority() {
    char* name = strtok(NULL, " ");
    char* priority = strtok(NULL, " ");
    
    if(name == NULL || priority == NULL) {
        serial_println("Error: Invalid Parameters");
        return ERROR;
    }
    
    int p = atoi(priority);
    
    if(p < 0 || p > 9) {
        serial_println("Error: The priority is invalid.");
        return ERROR;
    }
    
    PCB* pcb = findPCB(name);
    
    if(pcb == NULL) {
        serial_println("Error: A PCB of that name does not exist.");
        return ERROR;
    }
    if(pcb->priority==p) return CONTINUE;
    
    pcb->priority = p;
    
    if(pcb->rrb != BLOCKED) {
        removePCB(pcb);
        insertPCB(pcb);
    }
    
    displayPCB(pcb);
    
    return CONTINUE;
}

/**
 Display name, class, states, and priority of PCB
 */
int commShowPCB() {
    char* name = strtok(NULL, " ");
    PCB* pcb = findPCB(name);
    
    if(pcb != NULL) {
        displayPCB(pcb);
    }
    else {
        serial_println("Error: A PCB of that name does not exist.");
    }
    
    strclr(name);
    
    return CONTINUE;
}

/**
 Display info for PCBs in the ready queue
 */
int commShowReady() {
    PCB* pcb = readyQueue.head;
    
    while(pcb != NULL) {
        displayPCB(pcb);
        pcb = pcb->next;
    }
    
    return CONTINUE;
}

/**
 Display info for PCBs in the blocked queue
 */
int commShowBlocked() {
    PCB* pcb = blockedQueue.head;
    
    while(pcb != NULL) {
        displayPCB(pcb);
        pcb = pcb->next;
    }
    
    return CONTINUE;
}

/**
 Display info for PCBs in both queues
 */
int commShowAll() {
    serial_println("Ready Queue:");
    commShowReady();
    
    serial_println("Blocked Queue:");
    commShowBlocked();
    
    return CONTINUE;
}

/**
 Create PCB
 */
int commCreatePCB() {
    char *name = strtok(NULL, " ");
    char *cl = strtok(NULL, " ");
    char *pr = strtok(NULL, " ");
    
    if(name == NULL || cl == NULL || pr == NULL) {
        serial_println("Error: Invalid Parameters.");
        return ERROR;
    }
    
    if(strlen(name) > 20) {
        serial_println("Error: Name is too long (over 20 characters).");
        return ERROR;
    }
    
    int class = atoi(cl);
    int priority = atoi(pr);
    
    if(findPCB(name) != NULL) {
        serial_println("Error: A PCB of that name already exists.");
        return ERROR;
    }
    
    if(class < 1 || class > 2) {
        serial_println("Error: An invalid PCB type has been supplied.");
        return ERROR;
    }
    
    if(priority < 0 || priority > 9) {
        serial_println("Error: The priority is invalid.");
        return ERROR;
    }
    PCB *pcb = setupPCB(name, class, priority);
    insertPCB(pcb);
    displayPCB(pcb);
    
    return CONTINUE;
}

/**
 Delete PCB
 */
int commDeletePCB() {
    char* name = strtok(NULL, " ");
    
    if(name == NULL) {
        serial_println("Error: Invalid Parameters");
        return ERROR;
    }
    
    PCB* pcb = findPCB(name);
    
    if(pcb != NULL) {
        removePCB(pcb);
        freePCB(pcb);
    }
    else {
        serial_println("Error: A PCB of that name does not exist.");
        return ERROR;
    }
    
    serial_print("PCB Deleted: ");
    serial_println(name);
    
    return CONTINUE;
}

/**
 Change state of PCB to blocked
 */
int commBlock() {
    char *name = strtok(NULL, " ");
    
    if(name == NULL) {
        serial_println("Error: Invalid Parameters");
        return ERROR;
    }
    
    PCB* pcb = findPCB(name);
    
    if(pcb == NULL) {
        serial_println("Error: A PCB of that name does not exist.");
        return ERROR;
    }
    removePCB(pcb);
    pcb->rrb = BLOCKED;
    insertPCB(pcb);
    displayPCB(pcb);
    
    return CONTINUE;
}

/**
 Change state of PCB to unblocked
 */
int commUnblock() {
    char* name = strtok(NULL, " ");
    
    if(name == NULL) {
        serial_println("Error: Invalid Parameters");
        return ERROR;
    }
    
    PCB* pcb = findPCB(name);
    
    if(pcb == NULL) {
        serial_println("Error: A PCB of that name does not exist.");
        return ERROR;
    }
    
    if(pcb->rrb!=BLOCKED){
        serial_println("Error: This PCB is not blocked.");
        return ERROR;
    }
    
    removePCB(pcb);
    pcb->rrb = READY;
    insertPCB(pcb);
    displayPCB(pcb);
    
    return CONTINUE;
}

/**
 Clear both PCB queues
 */
int commClearQueues() {
    PCB* curr=readyQueue.head;
    PCB* next=curr->next;
    
    while(curr){
        freePCB(curr);
        curr=next;
        next=curr->next;
    }
    
    readyQueue.head=readyQueue.tail=NULL;
    curr=blockedQueue.head;
    next=curr->next;
    
    while(curr){
        freePCB(curr);
        curr=next;
        next=curr->next;
    }
    
    blockedQueue.head=blockedQueue.tail=NULL;
    
    return CONTINUE;
}

/**
 Handler for resmue all function
 */
int commResumeAll() {
    PCB* curr = readyQueue.head;
    
    while(curr) {
        curr->state = NOT_SUSPENDED;
        curr = curr->next;
    }
    
    curr = blockedQueue.head;
    
    while(curr) {
        curr->state = NOT_SUSPENDED;
        curr = curr->next;
    }
    
    return CONTINUE;
}

int readyEmpty() {
    if(readyQueue.head == NULL) {
        return 1;
    }
    return 0;
}

int blockedEmpty() {
    if(blockedQueue.head == NULL) {
        return 1;
    }
    return 0;
}
