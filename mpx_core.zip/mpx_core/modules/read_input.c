#include <stdint.h>
#include <system.h>
#include <string.h>
#include <core/serial.h>
#include <core/io.h>
#include "mpx_supt.h"
#include <modules/read_input.h>
#include <modules/commhand.h>

int getPrevLocation(void);
int nextLocation(void);
int getNextLocation(void);
int serial_input(char *buffer, int *count);

static char log[LOG_LIMIT][MAX_BUFF];
static int logLocation = 0;
static int currLocation = 0;

/**
 Helper methods for serial_input
 */
int getPrevLocation(void) {
    if(logLocation == 0) {
        return LOG_LIMIT - 1;
    }
    
    return logLocation - 1;
}

int nextLocation(void) {
    if(logLocation + 1 == LOG_LIMIT) {
        return 0;
    }
    return logLocation + 1;
}

int getNextLocation(void) {
    if(logLocation + 1 == LOG_LIMIT) {
        return 0;
    }
    return logLocation + 1;
}

/*
   Polls for keyboard input
*/
int serial_input(char *buffer, int *count) {
    
    int length = 0;
    int curr = 0;
    int c = (int) count;
    int prev = 0;
    
    char temp[2];
    temp[1] = '\0';
    
    while(1) {
        if(inb(COM1 + 5) & 1) {
            char letter = inb(COM1);
            temp[0] = letter;
            
            // ESCAPE KEY
            if(letter == '\033') {
                letter = inb(COM1);
                letter = inb(COM1);
                
                // UP ARROW
                if(letter == 'A') {
                    if(prev && (currLocation == logLocation)) {
                        // no previously entered commands
                    }
                    else if(*log[getPrevLocation()]) {
                        prev = 1;
                        currLocation = getPrevLocation();
                        buffer = strcpy(buffer, log[currLocation]);

                        int i;
                        for(i = curr; i < length; i++) {
                            serial_print(" ");
                        }
                        for(i = length; i > 0; i--) {
                            serial_print("\b \b");
                        }

                        if(buffer != NULL) {
                            serial_print(buffer);
                        }

                        length = strlen(buffer);
                        curr = length;
                    }
                }

                // DOWN ARROW
                else if(letter == 'B') {
                    if((logLocation == currLocation) || (currLocation == logLocation-1)) {
                        int i;
                        for(i = curr; i < length; i++) {
                            serial_print(" ");
                        }
                        for(i = length; i > 0; i--) {
                            serial_print("\b \b");
                        }

                        buffer[0] = '\0';
                        length = 0;
                        curr = length;
                    }
                    else if(*log[nextLocation()]) {
                        prev = 1;
                        currLocation = nextLocation();
                        buffer = strcpy(buffer, log[currLocation]);

                        int i;
                        for(i = curr; i < length; i++) {
                            serial_print(" ");
                        }
                        for(i = length; i > 0; i--) {
                            serial_print("\b \b");
                        }

                        if (buffer != NULL) {
                            serial_print(buffer);
                        }

                        length = strlen(buffer);
                        curr = length;
                    }
                }

                // RIGHT ARROW
                else if(letter == 'C') {
                    if(curr < length) {
                        temp[0] = buffer[curr];
                        serial_print(temp);
                        curr++;
                    }
                }

                // LEFT ARROW
                else if(letter == 'D') {
                    if(curr > 0) {
                        serial_print("\b");
                        curr--;
                    }
                }
                
                // DELETE
                else {
                    letter = inb(COM1);
                    
                    int i;
                    if (letter == '~' && curr != length) {
                        for (i = curr; i < length; i++) {
                            buffer[i] = buffer[i+1];
                            temp[0] = buffer[i+1];
                        }

                        buffer[i-1] = '\0';

                        for(i = curr; i <= length; i++) {
                            serial_print(" ");
                        }
                        for(i = length; i >= curr; i--) {
                            serial_print("\b \b");
                        }

                        serial_print(temp);
                        length--;

                        for(i = curr; i < length; i++) {
                            serial_print("\b");
                        }
                    }
                }
            }
             
            // BACKSPACE
            else if(letter == '\177') {
                if(curr == length && length != 0) {
                    serial_print("\b \b");
                    length--;
                    curr--;
                }
                else if(curr > 0) {
                    serial_print("\b");
                    
                    int i;
                    for(i = curr; i < length; i++) {
                        buffer[i-1] = buffer[i];
                        temp[0] = buffer[i-1];
                        serial_print(temp);
                    }
                    
                    serial_print(" ");
                    
                    for(i = curr; i <= length; i++) {
                        serial_print("\b");
                    }
                    
                    length--;
                    curr--;
                }
            }

            // CARRIAGE RETURNS AND NEW LINE
            else if(letter == '\n' || letter == '\r') {
                buffer[length] = '\0';

                if(strcmp(buffer, "") != 0) {
                    strcpy(log[logLocation], buffer);
                    logLocation = getNextLocation();
                }
                
                logLocation = currLocation;
                prev = 0;
                break;
            }
            
            // CHARACTER
            else if(length < c) {
                if(curr == length) {
                    buffer[curr] = letter;
                    serial_print(temp);
                }
                else {
                    char t;
                    char ch = letter;

                    int i;
                    for(i = curr; i <= length; i++) {
                        t = buffer[i];
                        buffer[i] = ch;
                        temp[0] = ch;
                        serial_print(temp);
                        ch = t;
                    }
                    for(i = curr; i < length; i++) {
                        serial_print("\b");
                    }
                }

                length++;
                curr++;
            }
        }
    }
    
    return CONTINUE;
    
}
