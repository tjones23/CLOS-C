#include <modules/commhand.h>
#include <modules/shutdown.h>
#include <modules/read_input.h>
#include <core/serial.h>
#include <string.h>
#include <system.h>

#include "mpx_supt.h"

/*
  Handler for shutdown command
*/
int shutdownComm(void) {
  char * in = '\0';
    int * mb = (int*) MAX_BUFF;

  serial_println("\nShutdown? 1 -> Confirm / 2 -> Cancel");

  while(1) {
      serial_print("\n$ shutdown: ");
      sys_req(READ, COM1, in, mb);
      serial_input(in, mb);

      if(strcmp(in, "2") == 0) {
          serial_println("");
          return CONTINUE;
      }
    else if(strcmp(in, "1") == 0) {
        serial_println("\nShutting down...");
        commClearQueues();
        return BREAK;
    }

    else serial_println("\nInvalid response.");
      
      strclr(in);

  }

  return CONTINUE;
}
