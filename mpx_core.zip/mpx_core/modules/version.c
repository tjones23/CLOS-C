#include <modules/commhand.h>
#include <modules/version.h>
#include <core/serial.h>
#include <string.h>
#include <system.h>

#include "mpx_supt.h"

/*
  Handles version command
*/
int versionComm(void) {
    char * version = "\nSystem Build: R6. 04/24/2019";
    
    serial_println(version);

    return CONTINUE;
}
